<?php
class ProductController 

{
    private $db;

    public function __construct() 
    
    {
        $this->db = (new Database())->getConnection();
    }

    public function listProducts() 
    
    {
        $stmt = $this->db->query("SELECT * FROM products ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addProduct($name, $stock, $price) 
    
    {
        try 
        
        {
            $stmt = $this->db->prepare("INSERT INTO products(name, stock, price) VALUES(:n, :s, :p)");
            return $stmt->execute(
                [
                ':n' => $name,
                ':s' => $stock,
                ':p' => $price
                ]
        );

        } catch (PDOException $e) 
        
        {
            return false;
        }
    }

    public function deleteProduct($id) 
    
    {
        $stmt = $this->db->prepare("DELETE FROM products WHERE id=:id");
        return $stmt->execute([':id'=>$id]);
    }
    
}

require_once "config/Database.php";

class OrderController {
    private $db;

    public function __construct() 
    
    {
        $this->db = (new Database())->getConnection();
    }

    //  Purchase product
    public function purchase($customer_id, $product_id, $quantity) 
    
    {
        // Get product price
        $stmt = $this->db->prepare("SELECT price, stock FROM products WHERE id=:id");
        $stmt->execute([':id' => $product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) return false; // product not found
        if ($product['stock'] < $quantity) return "Not enough stock!";

        $total = $product['price'] * $quantity;

        // Create order
        $orderStmt = $this->db->prepare(
            "INSERT INTO orders (customer_id, product_id, quantity, total) 
             VALUES (:c, :p, :q, :t)"
        );
        $orderStmt->execute([
            ':c' => $customer_id,
            ':p' => $product_id,
            ':q' => $quantity,
            ':t' => $total
        ]);

        // Reduce stock
        $updateStmt = $this->db->prepare("UPDATE products SET stock = stock - :q WHERE id=:id");
        $updateStmt->execute([
            ':q' => $quantity,
            ':id' => $product_id
        ]);

        return true;
    }

    //Get all orders for a customer
    public function listOrders($customer_id) 
    
    {
        $stmt = $this->db->prepare(
            "SELECT o.id, p.name as product_name, o.quantity, o.total, o.created_at 
             FROM orders o
             JOIN products p ON o.product_id = p.id
             WHERE o.customer_id=:cid
             ORDER BY o.id DESC"
        );
        $stmt->execute([':cid' => $customer_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}


?>
