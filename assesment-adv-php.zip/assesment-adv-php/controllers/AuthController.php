<?php
require_once "config/Database.php";

class AuthController 
{
    private $db;

    public function __construct() 
    
    {
        $this->db = (new Database())->getConnection();
    }

    public function register($name, $email, $password, $role) 
    
    {
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        $sql = "INSERT INTO users (name,email,password,role) VALUES (:n,:e,:p,:r)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':n'=>$name,
            ':e'=>$email,
            ':p'=>$hashed,
            ':r'=>$role
        ]);
    }

    public function login($email, $password) 
    
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email=:email");
        $stmt->execute([':email'=>$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if($user && password_verify($password,$user['password'])) 
            
            
            {
            $_SESSION['user'] = $user;
            return true;
        }
        return false;
    }
}
?>
