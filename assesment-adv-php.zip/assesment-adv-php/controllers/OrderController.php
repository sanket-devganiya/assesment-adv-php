<?php
require_once "config/Database.php";

class OrderController {
    private $db;
    public function __construct() 
    
    {
        $this->db = (new Database())->getConnection();
    }

    public function placeOrder($customer_id, $product_id, $qty) 
    
    {
        // Get product price & stock
        $stmt = $this->db->prepare("SELECT * FROM products WHERE id=:id");
        $stmt->execute([':id'=>$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if(!$product || $product['stock'] < $qty) return false;

        $total = $product['price'] * $qty;

        // Reduce stock
        $newStock = $product['stock'] - $qty;
        $this->db->prepare("UPDATE products SET stock=:s WHERE id=:id")
                 ->execute([':s'=>$newStock, ':id'=>$product_id]);

        // Insert order
        $stmt = $this->db->prepare("INSERT INTO orders(customer_id,product_id,quantity,total) VALUES(:c,:p,:q,:t)");
        return $stmt->execute([
            ':c'=>$customer_id, ':p'=>$product_id, ':q'=>$qty, ':t'=>$total
        ]);
    }

    public function getOrdersByCustomer($customer_id) {
        $stmt = $this->db->prepare("SELECT o.id, p.name, o.quantity, o.total, o.created_at 
            FROM orders o 
            JOIN products p ON o.product_id = p.id 
            WHERE o.customer_id = :cid");
        $stmt->execute([':cid'=>$customer_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
