<?php
session_start();
header("Location: routes.php?action=login_form");
exit;
?>
