<!DOCTYPE html>
<html>
<head>
  <title>My Orders</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mt-4">
    <h2>My Orders</h2>
    <?php if (!empty($orders)) : ?>
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($orders as $o): ?>
          <tr>
            <td><?= $o['id'] ?></td>
            <td><?= htmlspecialchars($o['product_name']) ?></td>
            <td><?= $o['quantity'] ?></td>
            <td>$<?= $o['total'] ?></td>
            <td><?= $o['created_at'] ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <div class="alert alert-info">No orders yet.</div>
    <?php endif; ?>
    <a href="routes.php?action=dashboard" class="btn btn-secondary">Back</a>
  </div>
</body>
</html>
