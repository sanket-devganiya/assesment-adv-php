<!DOCTYPE html>
<html>
<head>
  <title>Purchase Product</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mt-4">
    <h2>Purchase Products</h2>
    <form method="POST" action="routes.php?action=purchase">
      <div class="mb-3">
        <label>Select Product</label>
        <select name="product_id" class="form-select" required>
          <?php foreach($products as $p): ?>
            <option value="<?= $p['id'] ?>">
              <?= htmlspecialchars($p['name']) ?> - Stock: <?= $p['stock'] ?> - Price: $<?= $p['price'] ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="mb-3">
        <label>Quantity</label>
        <input type="number" name="quantity" class="form-control" min="1" required>
      </div>
      <button class="btn btn-primary">Purchase</button>
      <a href="routes.php?action=dashboard" class="btn btn-secondary">Cancel</a>
    </form>
  </div>
</body>
</html>
