<!DOCTYPE html>
<html>
<head>
  <title>Product List</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  <h2>Products</h2>
  <?php if(isset($_GET['msg'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div>
  <?php endif; ?>

  <a href="routes.php?action=add_product" class="btn btn-primary mb-3">+ Add Product</a>
  <a href="routes.php?action=dashboard" class="btn btn-primary mb-3"><-Back</a>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th><th>Name</th><th>Stock</th><th>Price</th><th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($products as $p): ?>
      <tr>
        <td><?= $p['id'] ?></td>
        <td><?= htmlspecialchars($p['name']) ?></td>
        <td><?= $p['stock'] ?></td>
        <td>$<?= $p['price'] ?></td>
        <td>
          <a href="routes.php?action=delete_product&id=<?= $p['id'] ?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Delete this product?')">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
</body>
</html>
