<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="routes.php?action=dashboard">Product MVC</a>
    <div class="d-flex">
      <?php if(isset($_SESSION['user'])): ?>
        <span class="text-white me-3">Welcome, <?= $_SESSION['user']['name'] ?> (<?= $_SESSION['user']['role'] ?>)</span>
        <a href="routes.php?action=logout" class="btn btn-danger btn-sm">Logout</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
