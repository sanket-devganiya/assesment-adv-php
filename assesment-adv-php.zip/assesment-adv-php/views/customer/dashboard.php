<h2>Welcome, <?= $_SESSION['name'] ?> (Customer)</h2>
<a href="routes.php?action=purchase" class="btn btn-success">Purchase Products</a>
<a href="routes.php?action=my_orders" class="btn btn-info">My Orders</a>
<a href="routes.php?action=logout" class="btn btn-danger">Logout</a>
