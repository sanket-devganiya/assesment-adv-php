<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <span class="navbar-brand">Product Management</span>
    <a href="routes.php?action=logout" class="btn btn-danger">Logout</a>
  </div>
</nav>
<div class="container mt-4">
  <h2>Welcome, <?= htmlspecialchars($_SESSION['user']['name'] ?? '') ?></h2>
  <div class="mt-4">
    <a href="routes.php?action=list_products" class="btn btn-primary">Manage Products</a>
  </div>
</div>
<?php if ($_SESSION['user']['role'] === 'customer'): ?>
  <div class="row">
    <div class="col-md-6">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5 class="card-title">Purchase Products</h5>
          <p class="card-text">Buy available products</p>
          <a href="routes.php?action=purchase" class="btn btn-primary">Purchase</a>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5 class="card-title">My Orders</h5>
          <p class="card-text">View your purchase history</p>
          <a href="routes.php?action=view_orders" class="btn btn-info">View Orders</a>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

</body>
</html>
