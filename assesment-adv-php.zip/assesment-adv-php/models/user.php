<?php
class User {
    protected $id;
    protected $name;
    protected $email;
    private $password; 
    protected $role;
    private $balance;

    public function __construct($name, $email, $password, $role) {
        $this->name = $name;
        $this->email = $email;
        $this->password = $password;
        $this->role = $role;
        $this->balance = 0;
    }

    public function getName() { return $this->name; }
    public function getEmail() { return $this->email; }
    public function getRole() { return $this->role; }
    public function getBalance() { return $this->balance; }
    protected function setBalance($amount) { $this->balance = $amount; }
}
?>
