<?php
class Order {
    public $id;
    public $customer_id;
    public $product_id;
    public $quantity;
    public $total;

    public function __construct($customer_id, $product_id, $quantity, $total) {
        $this->customer_id = $customer_id;
        $this->product_id = $product_id;
        $this->quantity = $quantity;
        $this->total = $total;
    }
}
?>
