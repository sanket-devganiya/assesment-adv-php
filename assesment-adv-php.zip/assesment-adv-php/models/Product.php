<?php
class Product {
    public $id;
    public $name;
    public $stock;
    public $price;

    public function __construct($name, $stock, $price) {
        $this->name = $name;
        $this->stock = $stock;
        $this->price = $price;
    }
}
?>
