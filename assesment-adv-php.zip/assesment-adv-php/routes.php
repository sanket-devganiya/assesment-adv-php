<?php
session_start();

require_once "controllers/AuthController.php";
require_once "controllers/ProductController.php";


$authController = new AuthController();
$productController = new ProductController();

$action = $_GET['action'] ?? 'login_form';  // default action

switch ($action) {

    /* ---------------- AUTH ACTIONS ---------------- */
    case 'login_form':
        include "views/auth/login.php";
        break;

    case 'register_form':
        include "views/auth/register.php";
        break;

    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];
            if ($authController->login($email, $password)) {
                header("Location: routes.php?action=dashboard");
                exit;
            } else {
                $error = "Invalid email or password";
                include "views/auth/login.php";
            }
        }
        break;

    case 'register':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $authController->register($_POST['name'], $_POST['email'], $_POST['password'], $_POST['role']);
            header("Location: routes.php?action=login_form");
            exit;
        }
        break;

    case 'logout':
        session_destroy();
        header("Location: routes.php?action=login_form");
        exit;

    /* ---------------- DASHBOARD ---------------- */
    case 'dashboard':
        if (!isset($_SESSION['user'])) {
            header("Location: routes.php?action=login_form");
            exit;
        }
        include "views/dashboard.php";
        break;

    /* ---------------- PRODUCT ACTIONS ---------------- */
    case 'list_products':
        $products = $productController->listProducts();
        include "views/products/list.php";
        break;

   case 'add_product':
    // Must be logged in
    if (!isset($_SESSION['user'])) {
        header("Location: routes.php?action=login_form");
        exit;
    }

    //  Must be a manager
    if ($_SESSION['user']['role'] !== 'manager') {
        echo "<div class='alert alert-danger text-center mt-3'>Access Denied! Only managers can add products.</div>";
        echo "<p class='text-center'><a href='routes.php?action=dashboard' class='btn btn-primary'>Go Back</a></p>";
        exit;
    }

    //  If form submitted (POST), save product
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name  = trim($_POST['name']);
        $stock = intval($_POST['stock']);
        $price = floatval($_POST['price']);

        if ($productController->addProduct($name, $stock, $price)) {
            // After saving, go back to product list
            header("Location: routes.php?action=list_products");
            exit;
        } else {
            $error = "Failed to add product. Please try again.";
        }
    }

    //  If GET request, or error occurred → show the Add Product form
    include "views/products/add.php";
    break;

 

    case 'save_product':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $productController->addProduct($_POST['name'], $_POST['stock'], $_POST['price']);
            header("Location: routes.php?action=list_products");
            exit;
        }
        break;

    case 'delete_product':
        if (isset($_GET['id'])) {
            $productController->deleteProduct($_GET['id']);
        }
        header("Location: routes.php?action=list_products");
        exit;

        case 'purchase':
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'customer') {
        echo "<div class='alert alert-danger text-center'>Access Denied! Only customers can purchase.</div>";
        exit;
    }

    $products = $productController->listProducts();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $product_id = $_POST['product_id'];
        $qty = $_POST['quantity'];

        $result = $orderController->purchase($_SESSION['user']['id'], $product_id, $qty);

        if ($result === true) {
            echo "<div class='alert alert-success text-center'>Purchase successful!</div>";
        } elseif (is_string($result)) {
            echo "<div class='alert alert-danger text-center'>$result</div>";
        } else {
            echo "<div class='alert alert-danger text-center'>Failed to purchase</div>";
        }
    }
    include "views/orders/purchase.php";
    break;

case 'view_orders':
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'customer') {
        echo "<div class='alert alert-danger text-center'>Access Denied! Only customers can view orders.</div>";
        exit;
    }
    $orders = $orderController->listOrders($_SESSION['user']['id']);
    include "views/orders/list.php";
    break;

    

    /* ---------------- DEFAULT: INVALID ---------------- */
    default:
        echo "<h2 style='color:red;text-align:center;'>Invalid action!</h2>";
        echo "<p style='text-align:center;'><a href='routes.php?action=dashboard'>Go Back</a></p>";
        break;
    
}
?>
